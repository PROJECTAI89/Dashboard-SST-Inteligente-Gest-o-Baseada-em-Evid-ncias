import React, { useState } from 'react';
import { AlertTriangle, ShieldCheck, ShieldAlert, X, ChevronRight, ArrowRight } from 'lucide-react';
import { RiscoMatriz } from '../../types/sst';

interface RiskMatrix3x3Props {
  riscos: RiscoMatriz[];
  onOpenAction?: (actionId: string) => void;
}

export const RiskMatrix3x3: React.FC<RiskMatrix3x3Props> = ({ riscos, onOpenAction }) => {
  const [selectedCell, setSelectedCell] = useState<{ prob: number; sev: number; name: string } | null>(null);

  // Group risks by (prob, sev)
  const getRisksForCell = (prob: number, sev: number) => {
    return riscos.filter((r) => r.probabilidade === prob && r.severidade === sev);
  };

  const getCellClassification = (prob: number, sev: number): { score: number; label: string; bg: string; border: string; text: string } => {
    const score = prob * sev;
    if (score >= 6) {
      return { score, label: 'Crítico', bg: 'bg-rose-950/40 hover:bg-rose-900/50', border: 'border-rose-500/40', text: 'text-rose-400' };
    }
    if (score >= 3) {
      return { score, label: 'Atenção', bg: 'bg-amber-950/40 hover:bg-amber-900/50', border: 'border-amber-500/40', text: 'text-amber-400' };
    }
    return { score, label: 'Aceitável', bg: 'bg-emerald-950/40 hover:bg-emerald-900/50', border: 'border-emerald-500/40', text: 'text-emerald-400' };
  };

  const activeModalRisks = selectedCell
    ? getRisksForCell(selectedCell.prob, selectedCell.sev)
    : [];

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 shadow-lg flex flex-col justify-between">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
            </div>
            <h3 className="text-sm font-bold text-white">Matriz de Riscos 3x3 (NR-01)</h3>
          </div>
          <p className="text-[11px] text-slate-400">Classificação P x S (Clique em qualquer quadrante para drill-down dos riscos)</p>
        </div>

        {/* Legend */}
        <div className="hidden sm:flex items-center gap-2 text-[10px]">
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> Aceitável (1-2)
          </span>
          <span className="flex items-center gap-1 text-amber-400">
            <span className="w-2 h-2 rounded-full bg-amber-500" /> Atenção (3-4)
          </span>
          <span className="flex items-center gap-1 text-rose-400">
            <span className="w-2 h-2 rounded-full bg-rose-500" /> Crítico (6-9)
          </span>
        </div>
      </div>

      {/* 3x3 Matrix Grid */}
      <div className="py-2">
        <div className="flex">
          {/* Y Axis Label (Probabilidade) */}
          <div className="flex flex-col justify-around pr-2 text-[11px] font-semibold text-slate-400 text-right w-20">
            <span className="text-rose-400">P3: Alta</span>
            <span className="text-amber-400">P2: Média</span>
            <span className="text-emerald-400">P1: Baixa</span>
          </div>

          {/* Matrix Cells */}
          <div className="flex-1 grid grid-cols-3 gap-2">
            {/* Row 3: Prob Alta (Sev 1, 2, 3) */}
            {[1, 2, 3].map((sev) => {
              const prob = 3;
              const cellRisks = getRisksForCell(prob, sev);
              const classif = getCellClassification(prob, sev);
              return (
                <button
                  key={`cell-${prob}-${sev}`}
                  onClick={() => setSelectedCell({ prob, sev, name: `Probabilidade Alta x Severidade ${sev === 1 ? 'Baixa' : sev === 2 ? 'Média' : 'Alta'}` })}
                  className={`p-3 rounded-lg border ${classif.border} ${classif.bg} transition-all flex flex-col items-center justify-center cursor-pointer group text-center`}
                >
                  <span className="text-[10px] font-mono uppercase text-slate-400">Score {classif.score}</span>
                  <span className={`text-xl font-extrabold ${classif.text}`}>{cellRisks.length}</span>
                  <span className="text-[10px] font-medium text-slate-300">{classif.label}</span>
                </button>
              );
            })}

            {/* Row 2: Prob Média (Sev 1, 2, 3) */}
            {[1, 2, 3].map((sev) => {
              const prob = 2;
              const cellRisks = getRisksForCell(prob, sev);
              const classif = getCellClassification(prob, sev);
              return (
                <button
                  key={`cell-${prob}-${sev}`}
                  onClick={() => setSelectedCell({ prob, sev, name: `Probabilidade Média x Severidade ${sev === 1 ? 'Baixa' : sev === 2 ? 'Média' : 'Alta'}` })}
                  className={`p-3 rounded-lg border ${classif.border} ${classif.bg} transition-all flex flex-col items-center justify-center cursor-pointer group text-center`}
                >
                  <span className="text-[10px] font-mono uppercase text-slate-400">Score {classif.score}</span>
                  <span className={`text-xl font-extrabold ${classif.text}`}>{cellRisks.length}</span>
                  <span className="text-[10px] font-medium text-slate-300">{classif.label}</span>
                </button>
              );
            })}

            {/* Row 1: Prob Baixa (Sev 1, 2, 3) */}
            {[1, 2, 3].map((sev) => {
              const prob = 1;
              const cellRisks = getRisksForCell(prob, sev);
              const classif = getCellClassification(prob, sev);
              return (
                <button
                  key={`cell-${prob}-${sev}`}
                  onClick={() => setSelectedCell({ prob, sev, name: `Probabilidade Baixa x Severidade ${sev === 1 ? 'Baixa' : sev === 2 ? 'Média' : 'Alta'}` })}
                  className={`p-3 rounded-lg border ${classif.border} ${classif.bg} transition-all flex flex-col items-center justify-center cursor-pointer group text-center`}
                >
                  <span className="text-[10px] font-mono uppercase text-slate-400">Score {classif.score}</span>
                  <span className={`text-xl font-extrabold ${classif.text}`}>{cellRisks.length}</span>
                  <span className="text-[10px] font-medium text-slate-300">{classif.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* X Axis Labels (Severidade) */}
        <div className="flex pl-20 pt-2 text-[11px] font-semibold text-slate-400 text-center">
          <div className="flex-1 text-emerald-400">S1: Baixa</div>
          <div className="flex-1 text-amber-400">S2: Média</div>
          <div className="flex-1 text-rose-400">S3: Alta</div>
        </div>
      </div>

      {/* Drill-down modal for cell */}
      {selectedCell && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-2xl w-full p-6 shadow-2xl animate-in fade-in zoom-in-95 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-sm font-bold text-white">Riscos Operacionais ({selectedCell.name})</h3>
                  <p className="text-[11px] text-slate-400">{activeModalRisks.length} risco(s) identificados nesta categoria</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCell(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-3 overflow-y-auto space-y-3 flex-1">
              {activeModalRisks.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">Nenhum risco cadastrado neste quadrante para o filtro selecionado.</p>
              ) : (
                activeModalRisks.map((risco) => (
                  <div key={risco.id} className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-amber-400">
                            {risco.codigo}
                          </span>
                          <span className="text-xs font-bold text-slate-100">{risco.perigo}</span>
                        </div>
                        <p className="text-xs text-rose-300 mt-0.5 font-medium">Risco: {risco.risco}</p>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        risco.status === 'Crítico Sem Barreira'
                          ? 'bg-rose-500/20 text-rose-400 border-rose-500/30 animate-pulse'
                          : 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                      }`}>
                        {risco.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 pt-1 border-t border-slate-900">
                      <div><strong>Local:</strong> {risco.unidadeNome} • {risco.setorNome}</div>
                      <div><strong>Expostos:</strong> {risco.trabalhadoresExpostos} colaboradores</div>
                      <div><strong>Fonte:</strong> {risco.fonteGeradora}</div>
                      <div><strong>Responsável:</strong> {risco.responsavel}</div>
                    </div>

                    <div className="pt-2 text-[11px] space-y-1">
                      <div className="text-slate-300">
                        <span className="text-slate-500">Controles Necessários:</span>{' '}
                        {risco.controlesNecessarios.join('; ')}
                      </div>
                      {risco.acaoVinculadaId && (
                        <div className="flex items-center gap-1.5 text-amber-400 font-medium pt-1">
                          <span>Ação Vinculada: {risco.acaoVinculadaId}</span>
                          {onOpenAction && (
                            <button
                              onClick={() => {
                                setSelectedCell(null);
                                onOpenAction(risco.acaoVinculadaId!);
                              }}
                              className="text-xs underline hover:text-amber-300 ml-2"
                            >
                              Ver Plano 5W2H →
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedCell(null)}
                className="px-4 py-1.5 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
